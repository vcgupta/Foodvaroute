export interface ICategories{
    name: string,
    image: string
}

export interface IRecipes{
    id: string,
    name: string,
    image: string,
    price: number,
    category: string,
    rating: number,
    reviews: number,
    details: string,
    isFavourite: boolean
}

export interface IFilter{
    category: string
}

export interface ICart{
    id: string,
    quantity: number
}

export interface IStoreState{
    categories: ICategories[],
    cartItems: ICart[],
    recipeList: IRecipes[]
}