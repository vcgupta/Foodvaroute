import * as React from 'react'
import { IRecipes, IStoreState } from '../dataDefinitions';
import {connect} from 'react-redux';

//import FavoriteItem from './FavoriteItem';


export interface IFavoriteProps {
    recipeList: IRecipes[],
    //onAddToCart: (id: string) => void
}

class Favorites extends React.Component<IFavoriteProps>{

    render() {
        console.log("In FV", this.props.recipeList);
        const favItems = this.props.recipeList.filter(recipe => recipe.isFavourite)
            .map(recipe => {
                //return <FavoriteItem recipe={recipe} />
                return this.favoriteItemRenderer(recipe);
            })
        return <div className="favourites">
            <div className="header-title"><h2>FAVORITES</h2>
                <span className="fav-desc">Enjoy what you have been ordering</span>
                {/* Bag icon here */}
            </div><div className="clear" />
            <div className="fav-items"> {favItems} </div>

        </div>
    };

    favoriteItemRenderer(recipe: IRecipes) {
        // const onClickItem = function(){
        //     this.props.onAddToCart(recipe.name);
        // }
        return (<div className="fav-item" key={recipe.name}>
            <div className="fav-img">
                <img src={recipe.image} alt={recipe.name} />
            </div>
            <div className="fav-shortdetails">
                <div className="name-price">
                    <div className="name">{recipe.name}</div>
                    <div className="price">{recipe.price}</div>
                </div>
                <div className="order-button">
                    <button className="btn order" >REORDER</button>
                </div>
            </div>
        </div>);
    }

    // onAddToCartItem(ev: any) {
    //     console.log("Reordering", this);
    // }

}


// function mapStateToProps(state: IStoreState, ownProps: IFavoriteProps) {
//     return state;
// }

// function mapDispatchToProps(dispatch: any) {
//     return {

//     }
// }

// export default connect(mapStateToProps, mapDispatchToProps)(Favorites);

export default Favorites