import React from "react";
import { IRecipes } from "../dataDefinitions";

export interface IFilteredItems{
    recipeList: IRecipes[]
}
export default class FilteredItems extends React.Component<IFilteredItems>{

    render(){
        const filteredItems = this.props.recipeList//.filter(recipe => recipe.isFavourite)
            .map(recipe => {
                //return <FavoriteItem recipe={recipe} />
                return this.filteredItemRenderer(recipe);
            })
        return <div className="filtered-Data">
           
           <div className="filter-items"> {filteredItems} </div>
            
        </div>
    }

    
    filteredItemRenderer(recipe: IRecipes) {
        return (<div className="filter-item" key={recipe.name}>
            <div className="filter-img">
                <img src={recipe.image} alt={recipe.name} />
            </div>
            <div className="filter-shortdetails">
                <div className="name-price">
                    <div className="name">{recipe.name}</div>
                    <div className="price">{recipe.price}</div>
                </div>
                <div className="order-button">
                    <button className="btn order">ADD TO BAG</button>
                </div>
            </div>
        </div>);
    }
}