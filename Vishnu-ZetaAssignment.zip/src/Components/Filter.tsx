import * as React from 'react';
import { ICategories } from '../dataDefinitions';
export interface ICategoryProps {
    categoryList: ICategories[],
    selectedCategory: string
}
export default class Filter extends React.Component<ICategoryProps> {
    render() {
        console.log("Able to access cat here", this.props.categoryList);

        const categories = this.props.categoryList.map(category => {
            //onClick={this.onCategoryChange.bind(category)}
            return (<div className="category" key={category.name}  onClick={this.onCategoryChange.bind(category)}>
                <img src={category.image} /><span>{category.name}</span>
            </div>);
        })

        return <div className="filter">
            <div className="header-title"><h2>SELECT CATEGORIES</h2>
                {/* Filters Button here */}
            </div>
<div className="clear" />
            <div className="categories">
                {categories}
            </div>
        </div>
    }

    onCategoryChange(ev: any){
        //if(this is instanceof(ICategories))
        console.log("Category changed to ", this);
        //if(this instanceof ICategories)
        //this.props.selectedCategory = this.name;
    }
}