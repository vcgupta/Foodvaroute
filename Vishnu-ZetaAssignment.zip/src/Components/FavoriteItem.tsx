
import * as React from 'react';
import { IRecipes } from '../dataDefinitions';

export interface IFavoriteItemProps{
    recipe: IRecipes
}
export default class FavoriteItem extends React.Component<IFavoriteItemProps>{

     
    constructor(props: IFavoriteItemProps) {
        super(props);
    }

    public render() {
        return <div className="fav-item">
            <div className="fav-img">
                <img src={this.props.recipe.image} alt={this.props.recipe.name} />
            </div>
            <div className="fav-shortdetails">
                <div className="name-price">
                    <div className="name">{this.props.recipe.name}</div>
                    <div className="price">{this.props.recipe.price}</div>
                </div>
                <div className="order-button">
                    <button className="btn order">REORDER</button>
                </div>
            </div>
        </div>
    }
}
