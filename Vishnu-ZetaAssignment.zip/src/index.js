import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {Provider} from 'react-redux'
import * as serviceWorker from './serviceWorker';
// import {IStoreState} from './dataDefinitions'
// import { createStore } from 'redux';


// const initialState: IStoreState = {
//     categories: [],
//     cartItems: [],
//     recipeList: []
// }

// function rootReducer(state = initialState, action:any) {
//     console.log(state, action);
//     // if (action.type === "ADD_TO_CART") {
//     //     return Object.assign({}, state, {
//     //         cartItems: [ ...cartItems, ]
            
//     //     })
//     // } 
//     return state;
// }
// const store = createStore(rootReducer);

// ReactDOM.render(<Provider store={store}><App /></Provider>, document.getElementById('root'));
ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
