import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Favorites from './Components/Favorites.tsx';
import { IStoreState } from './dataDefinitions.ts';
import Filter from './Components/Filter.tsx';
import FilteredItems from './Components/FilteredItems';

class App extends Component {

  constructor() {
    super();
    this.state = {
      categories: [],
      cartItems: [],
      recipeList: []
    }
  }

  componentWillMount() {
    setTimeout(async () => {
      fetch("http://temp.dash.zeta.in/food.php").then(async response => {
        const data = await response.json();
        console.log("Data is received", data);
        this.setState({
          categories: data.categories,
          recipeList: data.recipes
        });
      });
    });
  }
  render() {
    return (
      <div className="App">
        <Favorites recipeList={this.state.recipeList} />
        <Filter categoryList={this.state.categories} />
        <FilteredItems recipeList={this.state.recipeList} />
      </div>
    );
  }
}

export default App;
